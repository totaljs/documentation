 copy to Sublime Text 3 Packages:

 /Users/{USER NAME}/Library/Application Support/Sublime Text 3/Packages